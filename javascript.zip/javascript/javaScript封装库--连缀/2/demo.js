
/*
函数式
window.onload=function () {
	alert(getId("box").innerHTML);
	alert(getName("sex")[0].value);
	alert(getTag("p")[0].innerHTML);
};
*/

//对象式
// window.onload=function () {
// 	alert(Base.getId("box").innerHTML);
// 	alert(Base.getName("sex")[0].value);
// 	alert(Base.getTagName("p")[0].innerHTML);
// };

















